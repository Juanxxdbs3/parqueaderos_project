import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String selectedParking = "Ninguno";

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: const [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text('Opciones', style: TextStyle(color: Colors.white)),
            ),
            ListTile(
              leading: Icon(Icons.search),
              title: Text('Buscar Parqueadero'),
            ),
            ListTile(
              leading: Icon(Icons.history),
              title: Text('Historial de Pagos'),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Configuración'),
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: const Text('ParkItNow'),
        actions: [
          IconButton(
            icon: const CircleAvatar(child: Icon(Icons.person)),
            onPressed: () {
              // Aquí iría la lógica para mostrar perfil/sesión
              showModalBottomSheet(
                context: context,
                builder: (_) => const SizedBox(
                  height: 150,
                  child: Center(child: Text('Opciones de perfil')),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // 2/3 superior con el "mapa"
          SizedBox(
            height: screenHeight * 2 / 3,
            width: double.infinity,
            child: Container(
              color:
                  Colors.grey[300], // Puedes reemplazar esto por el mapa real
              child: const Center(child: Text("Aquí va el mapa")),
            ),
          ),
          // 1/3 inferior con detalles del parqueadero
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: Colors.grey.shade300)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Detalles del parqueadero:",
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text("Seleccionado: $selectedParking"),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: () {
                      // lógica futura
                    },
                    child: const Text("Reservar"),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
