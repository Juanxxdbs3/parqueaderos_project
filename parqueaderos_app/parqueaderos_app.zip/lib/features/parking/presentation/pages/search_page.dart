import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' as latlng;
import 'package:parqueaderos_app/config/injectors/dependency_injector.dart';
import 'package:parqueaderos_app/core/services/geolocator_service.dart';
import 'package:parqueaderos_app/core/services/location_service_result.dart'; // Importante
import 'package:parqueaderos_app/features/parking/domain/entities/parqueadero_entity.dart';
import 'package:parqueaderos_app/features/parking/domain/usecases/get_parqueaderos_cercanos_usecase.dart';
import 'package:provider/provider.dart';
import 'package:logging/logging.dart';

final Logger _logger = Logger('SearchPage');

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final MapController _mapController = MapController();
  List<ParqueaderoEntity> _parqueaderosCercanos = [];
  bool _isLoadingParkings = false;
  String?
      _apiErrorMessage; // Mensaje de error específico de la API de parqueaderos

  // Caso de uso inyectado
  late final GetParqueaderosCercanosUseCase _getParqueaderosCercanosUseCase;
  // Servicio de Geolocalización para llamar a openAppSettings/openLocationSettings
  late final GeolocatorService _geolocatorService;

  latlng.LatLng? _currentMapCenter; // Para saber dónde centrar el mapa

  @override
  void initState() {
    super.initState();
    _getParqueaderosCercanosUseCase = getIt<GetParqueaderosCercanosUseCase>();
    _geolocatorService = getIt<GeolocatorService>();
  }

  Future<void> _fetchNearbyParkings(double lat, double lon) async {
    if (!mounted) return;
    setState(() {
      _isLoadingParkings = true;
      _apiErrorMessage = null;
    });
    _logger.info('Buscando parqueaderos cercanos a Lat: $lat, Lon: $lon');

    final result = await _getParqueaderosCercanosUseCase(
      GetParqueaderosParams(lat: lat, lon: lon, radio: 5000),
    );

    if (!mounted) return;

    result.fold(
      (failure) {
        _logger.severe(
            'Error al obtener parqueaderos de la API: ${failure.message}');
        setState(() {
          _apiErrorMessage = failure.message;
          _parqueaderosCercanos = [];
          _isLoadingParkings = false;
        });
      },
      (parqueaderos) {
        _logger.info('${parqueaderos.length} parqueaderos encontrados.');
        setState(() {
          _parqueaderosCercanos = parqueaderos;
          _isLoadingParkings = false;
        });
      },
    );
  }

  void _updateMapCenterAndFetchParkings(latlng.LatLng newCenter) {
    if (_currentMapCenter != newCenter) {
      _currentMapCenter = newCenter;
      _logger.info(
          'Actualizando centro del mapa y buscando parqueaderos: Lat: ${newCenter.latitude}, Lon: ${newCenter.longitude}');

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          // Asegura que el widget esté montado
          try {
            _mapController.move(newCenter, 15.0);
          } catch (e) {
            _logger.warning("MapController no estaba listo para mover: $e");
          }
        }
      });
      _fetchNearbyParkings(newCenter.latitude, newCenter.longitude);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Obtiene el resultado del servicio de ubicación desde el FutureProvider
    final locationResult = Provider.of<LocationServiceResult?>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Buscar Parqueaderos'),
        actions: [
          if (_isLoadingParkings)
            const Padding(
              padding: EdgeInsets.only(right: 16.0),
              child: Center(
                  child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))),
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: (_currentMapCenter != null &&
                    locationResult is LocationSuccess)
                ? () => _fetchNearbyParkings(
                    _currentMapCenter!.latitude, _currentMapCenter!.longitude)
                : null,
            tooltip: 'Recargar parqueaderos',
          ),
        ],
      ),
      body: _buildBody(
          locationResult), // Llama a un método para construir el cuerpo
      floatingActionButton:
          (locationResult is LocationSuccess && _currentMapCenter != null)
              ? FloatingActionButton(
                  onPressed: () {
                    try {
                      _mapController.move(
                        latlng.LatLng((locationResult).position.latitude,
                            (locationResult).position.longitude),
                        15.0,
                      );
                    } catch (e) {
                      _logger.warning(
                          "MapController no estaba listo para mover en FAB: $e");
                    }
                  },
                  tooltip: 'Centrar en mi ubicación actual',
                  child: const Icon(Icons.my_location),
                )
              : null,
    );
  }

  Widget _buildBody(LocationServiceResult? locationResult) {
    if (locationResult == null) {
      // Aún cargando la ubicación inicial desde FutureProvider
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Obteniendo tu ubicación inicial...'),
          ],
        ),
      );
    }

    if (locationResult is LocationSuccess) {
      final currentPosition = locationResult.position;
      final newCenterForMap =
          latlng.LatLng(currentPosition.latitude, currentPosition.longitude);

      // Solo llama si el centro es diferente o es la primera vez
      if (_currentMapCenter == null ||
          _currentMapCenter!.latitude != newCenterForMap.latitude ||
          _currentMapCenter!.longitude != newCenterForMap.longitude) {
        // Usamos addPostFrameCallback para evitar setState durante build
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            // Asegurarse que el widget sigue montado
            _updateMapCenterAndFetchParkings(newCenterForMap);
          }
        });
      }

      return Column(
        children: [
          if (_apiErrorMessage != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('Error de API: $_apiErrorMessage',
                  style: const TextStyle(color: Colors.red)),
            ),
          Expanded(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: _currentMapCenter ??
                    newCenterForMap, // Usa el centro actual o el nuevo
                initialZoom: 15.0,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.example.parqueaderos_app',
                ),
                MarkerLayer(
                  markers: _buildMarkers(
                      currentPosition), // Pasa la posición actual para el marcador del usuario
                ),
              ],
            ),
          ),
        ],
      );
    }

    if (locationResult is LocationFailure) {
      // Manejar diferentes tipos de fallo de ubicación
      String message = locationResult.message;
      VoidCallback? buttonAction;
      String? buttonText;

      switch (locationResult.reason) {
        case LocationFailureReason.serviceDisabled:
          buttonAction = () => _geolocatorService.openLocationSettings();
          buttonText = 'Activar GPS';
          break;
        case LocationFailureReason.permissionDenied:
          // Aquí podrías simplemente mostrar el mensaje, o si quieres,
          // un botón para reintentar (que volvería a llamar a getCurrentLocation,
          // pero podría ser complejo de manejar el estado desde aquí).
          // Por ahora, solo mostramos el mensaje. El usuario puede salir y reentrar para el prompt.
          message =
              "El permiso de ubicación es necesario. Por favor, actívalo para usar esta función.";
          break;
        case LocationFailureReason.permissionDeniedForever:
          buttonAction = () => _geolocatorService.openAppSettings();
          buttonText = 'Abrir Configuración';
          break;
        case LocationFailureReason.unknownError:
          // Sin acción específica, solo mostrar el error
          break;
      }

      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Icon(Icons.location_off, size: 60, color: Colors.red),
              const SizedBox(height: 20),
              Text(
                'Problema de Ubicación',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 20),
              if (buttonAction != null && buttonText != null)
                ElevatedButton.icon(
                  icon: Icon(buttonText == 'Activar GPS'
                      ? Icons.gps_fixed
                      : Icons.settings),
                  onPressed: buttonAction,
                  label: Text(buttonText),
                ),
            ],
          ),
        ),
      );
    }

    // Estado por defecto o inesperado (no debería llegar aquí)
    return const Center(child: Text('Estado de ubicación inesperado.'));
  }

  List<Marker> _buildMarkers(Position? userPosition) {
    final List<Marker> markers = [];

    if (userPosition != null) {
      markers.add(
        Marker(
            width: 80.0,
            height: 80.0,
            point: latlng.LatLng(userPosition.latitude, userPosition.longitude),
            child: Tooltip(
              message: "Tu ubicación actual",
              child: Icon(Icons.person_pin_circle,
                  color: Theme.of(context).primaryColor, size: 40.0),
            )),
      );
    }

    for (var parqueadero in _parqueaderosCercanos) {
      markers.add(
        Marker(
          width: 100.0,
          height: 80.0,
          point: parqueadero
              .ubicacion, // Asumiendo que parqueadero.ubicacion es latlng.LatLng
          child: GestureDetector(
              onTap: () => _showParqueaderoDetails(context, parqueadero),
              child: Tooltip(
                message:
                    "${parqueadero.nombre}\nDisponibles: ${parqueadero.disponibles}",
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.local_parking,
                        color: Colors.redAccent[700], size: 30.0),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 3, vertical: 1),
                      decoration: BoxDecoration(
                          color: const Color.fromRGBO(0, 0, 0, 0.5),
                          borderRadius: BorderRadius.circular(3)),
                      child: Text(
                        parqueadero.nombre.length > 12
                            ? "${parqueadero.nombre.substring(0, 10)}..."
                            : parqueadero.nombre,
                        style:
                            const TextStyle(color: Colors.white, fontSize: 10),
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                      ),
                    )
                  ],
                ),
              )),
        ),
      );
    }
    return markers;
  }

  void _showParqueaderoDetails(
      BuildContext context, ParqueaderoEntity parqueadero) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return Container(
          padding: const EdgeInsets.all(16.0),
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.local_parking_sharp),
                title: Text(parqueadero.nombre,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(parqueadero.direccion),
              ),
              ListTile(
                leading: const Icon(Icons.event_available),
                title: const Text('Disponibles'),
                trailing: Text(
                    '${parqueadero.disponibles} / ${parqueadero.capacidadTotal}',
                    style: const TextStyle(fontSize: 16)),
              ),
              if (parqueadero.tarifaPorHora != null)
                ListTile(
                  leading: const Icon(Icons.payments_outlined),
                  title: const Text('Tarifa por Hora'),
                  trailing: Text(
                      '\$${parqueadero.tarifaPorHora?.toStringAsFixed(0) ?? 'N/A'}',
                      style: const TextStyle(fontSize: 16)),
                ),
              if (parqueadero.horario != null &&
                  parqueadero.horario!.isNotEmpty)
                ListTile(
                  leading: const Icon(Icons.access_time),
                  title: const Text('Horario'),
                  subtitle: Text(parqueadero.horario!),
                ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }
}
