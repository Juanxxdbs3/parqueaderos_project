import 'package:flutter/material.dart';
// Ya no necesitamos 'package:geolocator/geolocator.dart' directamente aquí para Position
import 'package:provider/provider.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'package:parqueaderos_app/features/parking/presentation/pages/search_page.dart';
import 'package:parqueaderos_app/core/services/geolocator_service.dart';
import 'package:parqueaderos_app/core/services/location_service_result.dart'; // Importar el nuevo tipo
import 'package:parqueaderos_app/config/injectors/dependency_injector.dart';
import 'package:logging/logging.dart'; // Si configuras logging aquí

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  configureDependencies();

  // Configuración de Logging (opcional, pero recomendado si lo usas)
  Logger.root.level = Level.ALL;
  Logger.root.onRecord.listen((record) {
    // ignore: avoid_print
    print(
        '${record.level.name}: ${record.time}: ${record.loggerName}: ${record.message}');
    if (record.error != null) {
      // ignore: avoid_print
      print('Error: ${record.error}, StackTrace: ${record.stackTrace}');
    }
  });

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Obtenemos la instancia de GeolocatorService desde getIt
    final GeolocatorService geolocatorService = getIt<GeolocatorService>();

    return FutureProvider<LocationServiceResult?>(
      // Ahora provee LocationServiceResult?
      // El FutureProvider puede devolver null si la creación del futuro falla,
      // aunque es mejor que el futuro mismo maneje todos sus estados de error internamente.
      // Hacemos que el futuro no sea nulo, y el tipo de dato sí.
      create: (context) => geolocatorService.getCurrentLocation(),
      initialData: null, // Mientras el futuro se resuelve
      catchError: (context, error) {
        // Manejar errores de la creación del futuro aquí si es necesario,
        // aunque GeolocatorService ya debería devolver un LocationFailure.
        Logger('MyApp').severe('Error en FutureProvider create: $error');
        // Devolver un estado de fallo por defecto si el futuro mismo falla catastróficamente.
        return LocationFailure(LocationFailureReason.unknownError,
            "Error inicializando el servicio de ubicación.");
      },
      child: MaterialApp(
        title: 'ParkItNow',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurpleAccent),
          useMaterial3: true,
        ),
        debugShowCheckedModeBanner: false,
        home: const SearchPage(),
      ),
    );
  }
}
